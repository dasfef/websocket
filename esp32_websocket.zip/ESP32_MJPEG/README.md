# ESP32 MJPEG Multiclient Streaming Server

ESP CAM이 하나의 클라이언트로 작동하는 문제점을 해결하기 위한 코드

url 주소 : http://192.168.0.46:5702/mjpeg/1

다중 클라이언트에서 동시 스트리밍 가능
